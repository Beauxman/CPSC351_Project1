#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/hash.h>
#include <linux/gcd.h>

int hello_init(void)    {
        printk(KERN_INFO "[Hello] Golden Radio: %lu", GOLDEN_RATIO_PRIME);
        return 0;
}

void hello_exit(void)   {
        printk(KERN_INFO "[Hello] GCD(3300, 24): %lu", gcd(3300, 24));
}

module_init(hello_init);
module_exit(hello_exit);
 
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Hello Module");
MODULE_AUTHOR("SGG"); 
